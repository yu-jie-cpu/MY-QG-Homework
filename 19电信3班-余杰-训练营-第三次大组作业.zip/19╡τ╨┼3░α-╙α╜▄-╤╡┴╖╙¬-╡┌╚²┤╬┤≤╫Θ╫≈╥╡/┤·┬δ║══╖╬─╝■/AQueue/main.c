#include <stdio.h>
#include <stdlib.h>
#include "AQueue.h"
#include <windows.h> 
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int DataSize = 0;
 
int main(int argc, char *argv[]) 
{
	start();
	system("pause");
	return 0;
}

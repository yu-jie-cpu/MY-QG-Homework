﻿#include <stdio.h>
#include <stdlib.h>
#include "Caltree.h"
#include <windows.h>


char string[LENGTH];        //记录每一次的中缀表达式，方便后序进行计算
int index = 0;
int pos = 0;

//创建一个基于数组的空栈
SqStack* createsqstack()
{
    PStack s;
    s = (PStack)malloc(sizeof(SqStack));
    s->top = -1;
    return s;
}

Status isEmptyStack(SqStack* s)//判断栈是否为空
{
    if (s->top == -1)
    {
        return SUCCESS;
    }
    else
    {
        return ERROR;
    }
}

Status getTopStack(SqStack* s, ElemType* e) //得到栈顶元素
{
    if (isEmptyStack(s))
    {
        return ERROR;
    }
    *e = s->elem[s->top];
    return SUCCESS;
}


Status pushStack(SqStack* s, ElemType data)//入栈
{
    if (s->top == MAXSIZE - 1)
    {
        return ERROR;
    }
    s->top++;
    s->elem[s->top] = data;
    return SUCCESS;
}

Status popStack(SqStack* s, ElemType* data)//出栈
{
    if (isEmptyStack(s))
    {
        return ERROR;
    }
    *data = s->elem[s->top];
    s->top--;
    return SUCCESS;
}

//优先级判断
Status judgeprior(int c, int* tag)
{
    switch (c)
    {
    case '(':   *tag = 0; return SUCCESS;
    case '+':
    case '-':   *tag = 1; return SUCCESS;
    case '*':
    case '/':   *tag = 2; return SUCCESS;
    default:  	*tag = -1; return ERROR;
    }
}



//计算两个数 
Status caclulate(PStack s1, int c)
{
    int a1, a2, a;
    popStack(s1, &a1);
    popStack(s1, &a2);
    //ASCIIA码 
    switch (c)
    {
    case '+':   a = a1 + a2; break;
    case '-':   a = a2 - a1; break;
    case '*':   a = a1 * a2; break;
    case '/':   a = a2 / a1; break;
    }
       pushStack(s1, a); //计算完后入栈 
       return SUCCESS;
}



//处理运算符的函数 
Status disposefuhao(PStack s1, PStack s2, int c)
{
    int p, tag1, tag2;
    if (isEmptyStack(s2) || c == '(')
    {
        //(入栈
        pushStack(s2, c);
        return SUCCESS;
    }
    //获得当前的符号栈的栈顶
    getTopStack(s2, &p);
    judgeprior(c, &tag1);
    judgeprior(p, &tag2);
    //将当前的符号栈的栈顶符号与传入的符号进行优先级比较
    if (tag1 > tag2)
    {
        pushStack(s2, c);		 //传入符号优先级大于当前栈顶，则传入符号入栈
        return SUCCESS;
    }

    while (tag1 <= tag2)		  //传入的符号优先级小于当前栈顶符号
    {
        popStack(s2, &p);
        caclulate(s1,  p);			 //将当前栈顶的符号取出与数字栈中顶端的两个数字进行计算
        if (isEmptyStack(s2))
        {
            break;		 		//如果计算完毕之后符号栈为空则break;
        }
        getTopStack(s2, &p);
        if (p == '(')				//这一部及其地关键!!!!!!!!!!!!!!!!!!!!!!!!调试了一个多小时 
            break;									//再次取出一个当前栈符号与传入符号比较,如果小于就继续计算 
    }
    pushStack(s2, c);				    //进行完毕优先级计算之后，再将新传入的符号入栈
    return SUCCESS;
}


//处理右括号函数 
Status disposekuohao(SqStack* s1, SqStack* s2)
{
    int p;	//记录栈顶 
    getTopStack(s2, &p);
    while (p != '(')	//匹配右括号和左括号 
    {

        popStack(s2, &p);		//当前符号出栈然后将数字出栈两个进行计算 
        caclulate(s1, p);
        getTopStack(s2, &p);		//然后再次取出当前符号栈栈顶符号，直到出现‘(’
    }
    popStack(s2, &p);			//丢弃左括号 
    return SUCCESS;
}

Status destroyStack(PStack s)//销毁栈
{
    free(s);
    return SUCCESS;
}

void disposemid()
{
    SqStack* s1 = NULL;
    SqStack* s2 = NULL;
    s1 = createsqstack();	//存放数字
    s2 = createsqstack();	//存放运算符
    int i, data, flag, p;
    i = data = flag = p = 0;
    //flag作为data是否有数值的判断 
    while (string[i] != '\0')
    {
        if (string[i] == ' ')
        {
            i++;
            continue;
        }

        //处理数字 
        if (string[i] >= '0' && string[i] <= '9')
        {
            data = data * 10 + string[i] - '0';
            flag = 1;
        }

        else
        {
            if (flag == 1)
            {
                pushStack(s1, data);
                flag = data = 0; //清零 
            }
            if (string[i] == ')')
            {
                //处理右括号
                disposekuohao(s1, s2);
            }
            else	//处理加减乘除 
            {
                disposefuhao(s1, s2, string[i]);
            }
        }
        i++;
    }

    //如果flag = 1.说明data里面还有数值,将其入栈 
    if (flag == 1)
    {
        pushStack(s1, data);
    }
    //开始计算 
    while (isEmptyStack(s2) != 1)
    {
        popStack(s2, &p);
        caclulate(s1, p);
    }
    //取出数字栈最后剩下的数据 
    popStack(s1, &data);

    //打印结果
    printf("\n中缀表达式的计算结果为：%s = %d\n", string, data);
    destroyStack(s1);
    destroyStack(s2);
    memset(string, 0, LENGTH);
}


//交互界面
void show(void)
{
    printf("<--------------CalculateTree-------------->\n");
    printf("<1> 使用系统默认的前缀表达式\n");
    printf("<2> 自行输入一个前缀表达式\n");
    printf("<0> 退出终端\n");
    printf("<------------------------------------------->\n");
}

void show1(BTREE T)
{
    char op = 1;
    system("cls");
    printf("<--------------CalculateTree-------------->\n");
    printf("<1> 利用先序遍历打印前缀表达式\n");
    printf("<2> 利用中序遍历打印中缀表达式\n");
    printf("<3> 利用后序遍历打印后缀表达式\n");
    printf("<0> 返回上一级\n");
    printf("<------------------------------------------->\n");
    while (op != '0')
    {
        printf("输入您的选择：");
        scanf_s("%c", &op);
        while (getchar() != '\n');
        switch (op)
        {
        case '1':    printf("前缀表达式："); searchPrefix(T); printf("\n"); break;
        case '2':    printf("中缀表达式："); index = 0; searchInfix(T);  printf("\n"); disposemid();  break;
        case '3':   printf("后缀表达式："); searchPostfix(T); printf("\n");  break;
        case '0':   system("cls"); break;
        default:printf("输入错误\n"); break;
        }
    }
}



void founction1(void)
{
    BTREE T;
    char infix[] = " -*2 * +4 3 1 6 ";
    printf("系统的前缀表达式为:%s\n", infix);
    pos = 0;        //每次进行都要初始化，不然会字符串数组的下标将错误
    createPrefix_recursive(infix, T);
    printf("构造二叉树成功！！！\n");
    PauseAndGo();
    show1(T);
    DestroyBiTree(&T);
    free(T);
}

void founction2(void)
{
    BTREE T;
    char infix[20];
    printf("请用户输入一个前缀表达式(长度不超过20)：");
    gets_s(infix);
    pos = 0;        //每次进行都要初始化，不然会字符串数组的下标将错误
    printf("系统的前缀表达式为:%s\n", infix);
    createPrefix_recursive(infix, T);
    printf("构造二叉树成功！！！\n");
    PauseAndGo();
    show1(T);
    DestroyBiTree(&T);
    free(T);
}



//暂停和继续（包括吸收一个回车键）
void PauseAndGo()
{
    char stop;
    printf("请输入回车继续...");
    stop = getchar();
    stop = getchar();

    while (stop != '\n')
    {
        stop = getchar();
    }
}






/*将前缀表达式转化为中缀表达式*/

char nextToken(char infix[])//括号、操作数、操作符等 都为一个字符 
{
    while (infix[pos] != '\0' && infix[pos] == ' ')
    { 
        pos++;  //跳过空格      
    }     
    return infix[pos++];
}

int isOpNum(char ch)            //是否是操作数 
{
    if (ch == '#' || ch == '(' || ch == ')' || ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == ' ' || ch == '|')
    {
        return 0;
    }
    return 1;
}


//递归方式_由前缀表达式构建表达式树 
void createPrefix_recursive(char prefix[],  BTREE& T)
{
    char x = nextToken(prefix);

    T = (BTREE)malloc(sizeof(BTNode));
    T->data = x;
    T->lchild = NULL;
    T->rchild = NULL;

    if (!isOpNum(x))//是操作符。前缀表达式的最后一个字符一定是操作数，所以下面的递归会停止。 
    {
        createPrefix_recursive(prefix, T->lchild);
        createPrefix_recursive(prefix, T->rchild);
    }
}

//递归打印前缀表达式，前序遍历
void searchPrefix(BTREE T)
{
    if (T != NULL)
    {
        printf("%c", T->data);
        searchPrefix(T->lchild);
        searchPrefix(T->rchild);       
    }
}

//递归打印中缀表达式，中序遍历
void searchInfix(BTREE T)
{
    if (T != NULL)
    {
        if (T->lchild != NULL && T->rchild != NULL) 
        { 
            printf("("); string[index++] = '(';     //当为括号时要补上括号
        }

        searchInfix(T->lchild);
        printf("%c", T->data);
        string[index++] = T->data;      //记录遍历出来的中缀表达式，便于后序的计算
        searchInfix(T->rchild);

        if (T->lchild != NULL && T->rchild != NULL) 
        { 
            printf(")"); string[index++] = ')';
        }
    }
}

//递归打印后序表达式，后序遍历
void searchPostfix(BTREE T)
{
    if (T != NULL)
    {
        searchPostfix(T->lchild);
        searchPostfix(T->rchild);
        printf("%c", T->data);
    }
}

Status DestroyBiTree(BTREE * T)
{
    if (*T)
    {
        if ((*T)->lchild) /* 有左孩子 */
            DestroyBiTree(&(*T)->lchild); /* 销毁左孩子子树 */
        if ((*T)->rchild) /* 有右孩子 */
            DestroyBiTree(&(*T)->rchild); /* 销毁右孩子子树 */
        free(*T); /* 释放根结点 */
        *T = NULL; /* 空指针赋0 */
    }
    return SUCCESS;
}

//操作结果：构造空二叉树T
Status InitBiTree(BTREE* T)
{
    *T = NULL;
    printf("构造二叉树成功！\n");
    return SUCCESS;
}
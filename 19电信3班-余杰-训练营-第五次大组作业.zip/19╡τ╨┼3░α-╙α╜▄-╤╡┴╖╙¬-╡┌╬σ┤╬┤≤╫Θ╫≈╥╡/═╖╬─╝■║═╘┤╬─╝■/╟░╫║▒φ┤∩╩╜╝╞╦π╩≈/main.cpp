#include <iostream>
#include <stdio.h>
#include "Caltree.h"
#include "windows.h"


int main()
{
    char op = '1';
    while (op != '0')
    {
        system("color E");
        show();
        printf("��������ѡ��");
        scanf_s("%c", &op);
        while (getchar() != '\n');
        switch (op)
        {
        case '1': founction1(); break;
        case '2': founction2(); break;
        case '0': break;
        default:printf("�������\n"); break;
        }
    }
    system("pause");
    return 0;
}



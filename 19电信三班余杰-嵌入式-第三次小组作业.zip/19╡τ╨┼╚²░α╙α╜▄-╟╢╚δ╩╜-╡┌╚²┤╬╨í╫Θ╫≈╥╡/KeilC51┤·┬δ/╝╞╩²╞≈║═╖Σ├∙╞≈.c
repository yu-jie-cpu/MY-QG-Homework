#include "reg52.h"

typedef unsigned int u16;
typedef unsigned char u8;


u8 code smgduan[] = {0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,
					 0x7f,0x6f,0x77,0x7c,0x39,0x5e,0x79,0x71,0x00};

u8 code str[] = {0x76,0x79,0x38,0x38,0x3f};

u8 code wei[] = {0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07};
 
void delay(u16 n)
{
	u16 i,j;
	for(i=0; i<n; i++)
	{
		for(j=0; j<120; j++);
	}
}


 
void showshuma()
{
	 u8 i = 0;
	 u8 j = 0;
	 for(i=0; i<5; i++)
	 {
		P3 = wei[i];
		P2 = str[i];
		delay(500);
	 }	
	 
	 for(j=0; j<10; j++)
		{
			P3 = wei[7];
			P2 = smgduan[j];
			delay(1000);
		}
} 
 
void main()
{ 
	 while(1)
	 {
	 	P1 = 0X00;
	 	showshuma();
		delay(100);
	 }
}
#include "reg52.h"
#include "intrins.h"

typedef unsigned int u16;
typedef unsigned char u8;

#define led P2

void delay(u16 i)
{
	while(i--);
}

void ledflash()
{
	u8 i = 0;
	for(i=0; i<8; i++)
	{
		led = ~(0x01<<i);	//0000 0001 -> 0000 0010
		delay(50000);
	}
}


void main()
{
	while(1)
	{
		ledflash();
	}

}
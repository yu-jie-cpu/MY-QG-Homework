#include "linkedList.h"
#include <stdio.h>
#include <Windows.h>

int main()
{
	initstart();
	return 0;
}

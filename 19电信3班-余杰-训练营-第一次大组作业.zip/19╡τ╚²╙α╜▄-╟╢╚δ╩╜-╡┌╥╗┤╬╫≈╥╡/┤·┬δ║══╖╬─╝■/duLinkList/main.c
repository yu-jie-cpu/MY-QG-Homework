#include <stdio.h>
#include <stdlib.h>
#include "duLinkedList.h"
#include<windows.h>

int main()
{
	initstart(); 
	system("pause");
	return 0;
}
